#!/bin/bash
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.10w data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.1M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.2M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.3M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.4M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.5M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.6M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.7M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.8M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.9M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.10M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.11M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.12M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.13M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.14M data/syntax
hadoop fs -put /home/wmt/data/UNPC/tmp/UNPC.15M data/syntax
