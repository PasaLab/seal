#!/bin/bash
head -100000 mergedAll > ./tmp/UNPC.10w
head -1000000 mergedAll > ./tmp/UNPC.1M
head -2000000 mergedAll > ./tmp/UNPC.2M
head -3000000 mergedAll > ./tmp/UNPC.3M
head -4000000 mergedAll > ./tmp/UNPC.4M
head -5000000 mergedAll > ./tmp/UNPC.5M
head -6000000 mergedAll > ./tmp/UNPC.6M
head -7000000 mergedAll > ./tmp/UNPC.7M
head -8000000 mergedAll > ./tmp/UNPC.8M
head -9000000 mergedAll > ./tmp/UNPC.9M
head -10000000 mergedAll > ./tmp/UNPC.10M
head -11000000 mergedAll > ./tmp/UNPC.11M
head -12000000 mergedAll > ./tmp/UNPC.12M
head -13000000 mergedAll > ./tmp/UNPC.13M
head -14000000 mergedAll > ./tmp/UNPC.14M
head -15000000 mergedAll > ./tmp/UNPC.15M
